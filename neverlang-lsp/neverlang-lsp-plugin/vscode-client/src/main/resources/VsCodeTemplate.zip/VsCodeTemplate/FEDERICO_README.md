It should be enough run these commands:
```bash
yarn install
npm install
npm install --save-dev typescript@latest
# RESTART VSCODE
```

Eventually:
```bash
npm install --save-dev typescript@latest # npm install typescript -g
npx tsc
```
